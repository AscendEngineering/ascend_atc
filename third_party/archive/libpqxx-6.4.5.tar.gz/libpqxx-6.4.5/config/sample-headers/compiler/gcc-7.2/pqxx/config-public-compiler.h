/* Automatically generated from config.h: public/compiler config. */

#define PQXX_HAVE_DEPRECATED 1
#define PQXX_HAVE_EXP_OPTIONAL 1
#define PQXX_HAVE_GCC_CONST 1
#define PQXX_HAVE_GCC_PURE 1
